<?php
/**
 * @ package    Seven News Module
 * @ version    1.0
 * @ author     7Studio Tomasz Herudzinski http://www.7studio.eu
 * @ copyright  Copyrights (C) 2009 - 2013 7Studio Tomasz Herudzinski
 * @ built for  Joomla! CMS, Joomla! is Free Software Released under GNU/GPL License: http://www.gnu.org/copyleft/gpl.html
 *
**/

defined('_JEXEC') or die;
?>
<div class="st-newsflash">

	<div class="module-title pull-left">
	<h3><?php echo htmlspecialchars($params->get('latest_newstext')); ?></h3>
	</div>
	
	<div class="flex-slider-container">
		<div id="news-slider-<?php echo $id; ?>" class="flexslider">
				
			<ul class="slides">
			<?php $counter = 0; ?>
			<?php foreach ($list as $item) : ?>
			
				<li>
					<p class="seven-news-text">
				<?php if ($params->get('item_title')) : ?>
						<?php if ($params->get('link_titles') && $item->link != '') : ?>
							<a class="news-title-link" href="<?php echo $item->link;?>">
								<?php echo $item->title;?>
							</a>
						<?php else : ?>
							<span class="news-title"><?php echo $item->title; ?></span>
						<?php endif; ?>

				<?php endif; ?>

				<?php echo $item->displayIntrotext; ?>

					<?php if (isset($item->link) && $item->readmore != 0 && $params->get('readmore')) : ?>
						<a class="readmore" href="<?php echo $item->link; ?>"><?php echo $item->linkText; ?></a>
					<?php endif; ?>
					</p>
				</li>
				
			<?php endforeach; ?>
			</ul>
			
			<?php if ($params->get('nav_buttons')) : ?>
			<ul class="flex-direction-nav news">
				<li><a href="#" class="flex-prev flex-disabled">Previous</a></li>
				<li><a href="#" class="flex-next">Next</a></li>
			</ul>
			<?php endif; ?>

		</div>
	</div>

</div>

